# -*- coding: utf-8 -*-
import xbmcgui
# Petit message de debug au chargement du fichier
xbmcgui.Dialog().ok("DEBUG", "Le script flixprimeplus se lance bien !")

import sys
import os
import urllib.parse
import requests
import re
import hashlib
import time
from bs4 import BeautifulSoup
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration de l'Addon ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
HASH_LIST_URL = "https://raw.githubusercontent.com/equationstratos/crypted/main/hashes.txt"

def log(msg):
    xbmc.log(f"STRATFLIX_DEBUG: {msg}", xbmc.LOGINFO)

# --- Configuration Images LOCALES ---
def get_art(filename):
    """Va chercher l'image dans le dossier resources/icones-menu de l'addon"""
    return os.path.join(ADDON_PATH, 'resources', 'icones-menu', filename)

# --- Système de Licence ---
def verifier_licence():
    """Système de verrouillage par clé SHA-256"""
    log("Lancement de la vérification de licence...")
    
    license_hash = ADDON.getSetting('stratflix_license_hash')
    activation_date = ADDON.getSetting('stratflix_date')
    
    # Vérification si déjà activé (validité 1 an)
    if license_hash and activation_date:
        try:
            expiration_time = float(activation_date) + (365 * 24 * 3600)
            if time.time() < expiration_time:
                return True
            else:
                xbmcgui.Dialog().ok("Stratflix", "Votre accès a expiré (validité 1 an).")
        except: pass
    
    # Demande de saisie
    kb = xbmcgui.Dialog().input("Activation Stratflix (Clé de 20 caractères)", type=xbmcgui.INPUT_ALPHANUM)
    
    if not kb or len(kb) != 20:
        xbmcgui.Dialog().ok("Accès Refusé", "Code invalide ou saisie annulée.")
        return False
        
    saisie_hash = hashlib.sha256(kb.upper().encode()).hexdigest()
    
    try:
        xbmcgui.Dialog().notification("Sécurité", "Vérification...", xbmcgui.NOTIFICATION_INFO, 2000)
        r = requests.get(HASH_LIST_URL, timeout=10)
        if r.status_code == 200:
            hashes_valides = [h.strip().lower() for h in r.text.splitlines() if h.strip()]
            if saisie_hash.lower() in hashes_valides:
                ADDON.setSetting('stratflix_license_hash', saisie_hash)
                ADDON.setSetting('stratflix_date', str(time.time()))
                xbmcgui.Dialog().ok("Succès", "Code validé ! Bienvenue.")
                return True
    except: pass
    
    xbmcgui.Dialog().ok("Erreur", "Code invalide ou problème réseau.")
    return False

# --- Menus ---

def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    add_item("[COLOR cyan]RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("home.png"))
    genres = [
        ("ACTION", "/film-en-streaming/action/", "action.png"),
        ("ANIMATION", "/film-en-streaming/animation/", "animation.png"),
        ("ARTS MARTIAUX", "/film-en-streaming/arts-martiaux/", "karate.png"),
        ("AVENTURE", "/film-en-streaming/aventure/", "adventure.png"),
        ("COMEDIE", "/film-en-streaming/comedie/", "comedy.png"),
        ("HORREUR", "/film-en-streaming/epouvante-horreur/", "horror.png"),
        ("SCIENCE FICTION", "/film-en-streaming/science-fiction/", "sci-fi.png"),
        ("THRILLER", "/film-en-streaming/thriller/", "thriller.png")
    ]
    for name, path, icon in genres:
        add_item(name, "list_movies", BASE_URL + path, thumb=get_art(icon))
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", fanart="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb or not os.path.exists(thumb): thumb = os.path.join(ADDON_PATH, 'icon.png')
    if not fanart or not os.path.exists(fanart): fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    
    li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
    
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping & Co ---

def get_html(url, post_data=None):
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def fetch_synopsis(movie_url):
    html = get_html(movie_url)
    if not html: return ""
    soup = BeautifulSoup(html, 'html.parser')
    desc = soup.find('div', class_='screenshots-full')
    return desc.get_text(" ", strip=True).split("Synopsis:")[-1] if desc and "Synopsis:" in desc.get_text() else "Aucun résumé."

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    html = get_html(url, post_data)
    if not html: return
    
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div', class_='mov')
    
    movie_list = []
    for item in items:
        link = item.find('a', class_='mov-t')
        if link:
            title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
            movie_list.append({'title': title, 'url': link['href'], 'thumb': thumb})

    # Récupération rapide des synopsis (10 threads)
    with ThreadPoolExecutor(max_workers=10) as executor:
        synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

    for i, m in enumerate(movie_list):
        li = xbmcgui.ListItem(label=m['title'])
        li.setArt({'thumb': m['thumb'], 'poster': m['thumb'], 'fanart': m['thumb']})
        info = li.getVideoInfoTag()
        info.setPlot(synopses[i])
        q = urllib.parse.urlencode({'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb']})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)

    # Pagination simplifiée
    match = re.search(r'/page/(\d+)', url)
    curr = int(match.group(1)) if match else 1
    next_url = url.replace(f'/page/{curr}', f'/page/{curr+1}') if match else url.rstrip('/') + '/page/2/'
    add_item("[COLOR green]PAGE SUIVANTE[/COLOR]", "list_movies", next_url, thumb=get_art("next.png"))
    
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label="▶ LIEN STREAMING")
        li.setArt({'thumb': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- Router ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    # LE VERROU
    if verifier_licence():
        if not action: main_menu()
        elif action == 'main': main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
