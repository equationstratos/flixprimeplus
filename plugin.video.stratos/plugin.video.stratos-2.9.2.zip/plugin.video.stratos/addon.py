# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    return os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)

# --- Sécurité ---
def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'): return True
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        if r.json().get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            return True
    except: pass
    return False

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    xbmcplugin.endOfDirectory(HANDLE)

# --- SCRAPER SYNOPSIS ---
def fetch_synopsis(url):
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=5)
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html.parser')
        # On cherche le synopsis dans la zone "screenshots-full" ou "mov-desc"
        target = soup.find('div', class_='screenshots-full') or soup.find('div', class_='mov-desc')
        if target:
            txt = target.get_text(strip=True)
            return txt.split("Complet:")[-1].replace("Synopsis:", "").strip()
    except: pass
    return "Résumé non disponible."

# --- LISTAGE ET NAVIGATION ---
def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    # 1. BOUTON ALLER À LA PAGE (Restauré)
    add_item("[COLOR gold]🔢 ALLER À LA PAGE X[/COLOR]", "go_to_page", url, thumb=get_art("pages.png"))

    try:
        r = requests.post(url, data=post_data, headers={'User-Agent': USER_AGENT}) if post_data else requests.get(url, headers={'User-Agent': USER_AGENT})
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html.parser')
        
        # Le site utilise maintenant 'mov' pour les conteneurs
        items = soup.find_all('div', class_='mov')
        movie_list = []
        
        for item in items:
            # Recherche du lien et titre
            t_tag = item.find('a', class_='mov-t')
            if not t_tag: continue
            
            title = t_tag.get_text(strip=True)
            m_url = t_tag['href']
            if not m_url.startswith('http'): m_url = BASE_URL + m_url
            
            # Recherche image
            img = item.find('img')
            thumb = img['src'] if img else ""
            if thumb.startswith('/'): thumb = BASE_URL + thumb
            
            movie_list.append({'title': title, 'url': m_url, 'thumb': thumb})

        # Extraction synopsis en parallèle
        with ThreadPoolExecutor(max_workers=10) as executor:
            plots = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

        for i, m in enumerate(movie_list):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=plots[i])

        # 2. PAGINATION SUIVANTE (Restaurée et simplifiée)
        nav = soup.find('div', class_='navigation')
        if nav:
            # On cherche le lien qui contient "Suivant", ">" ou "»"
            next_link = nav.find('a', string=re.compile(r'Suivant|Next|>|»'))
            if next_link:
                n_url = next_link['href']
                if not n_url.startswith('http'): n_url = BASE_URL + n_url
                add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))
                
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def go_to_page(url):
    kb = xbmcgui.Dialog().input("Numéro de page :", type=xbmcgui.INPUT_NUMBER)
    if kb:
        # Nettoyage de l'URL pour gérer le format /page/X/
        base = re.sub(r'page/\d+/?', '', url).rstrip('/')
        new_url = f"{base}/page/{kb}/"
        list_movies(new_url)

def add_item(name, action, url, thumb="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb: thumb = os.path.join(ADDON_PATH, 'icon.png')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    if plot:
        # Double injection pour être sûr que ça s'affiche à côté de l'affiche
        li.setInfo('video', {'plot': plot, 'plotoutline': plot, 'title': name})
        try:
            li.getVideoInfoTag().setPlot(plot)
        except: pass

    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- SOURCES ET LECTURE ---
def select_source(url):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    # Capture des liens loadVideo('URL')
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        name = "SERVEUR"
        if 'voe' in v_url.lower(): name = "VOE"
        elif 'uqload' in v_url.lower(): name = "UQLOAD"
        
        li = xbmcgui.ListItem(label=f"▶ {name}")
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Rechercher...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", post_data=data)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    if verifier_licence():
        if not action: main_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'go_to_page': go_to_page(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else: xbmcplugin.endOfDirectory(HANDLE, False)
