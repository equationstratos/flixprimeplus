# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Sécurité & Activation ---

def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'):
        return True
    
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        
        # Envoi au serveur
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        res = r.json()
        
        if res.get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            xbmcgui.Dialog().ok("Activation", "Félicitations, votre accès est activé !")
            return True
        else:
            xbmcgui.Dialog().ok("Erreur", f"Échec : {res.get('message')}")
            return False
    except Exception as e:
        xbmcgui.Dialog().ok("Serveur", "Erreur de connexion au serveur d'activation.")
        return False

# --- Scraping des synopsis ---

def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc = soup.find('div', class_='screenshots-full')
        if desc:
            t = desc.get_text(" ", strip=True)
            return t.split("Synopsis:")[-1].strip() if "Synopsis:" in t else t
    except: pass
    return "Aucun résumé disponible."

# --- Moteur d'affichage ---

def add_item(name, action, url, thumb="", plot="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    
    params = {'action': action, 'url': url, 'plot': plot, 'thumb': thumb}
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]📺 SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("Action", "action"), ("Animation", "animation"), ("Aventure", "aventure"),
        ("Comédie", "comedie"), ("Horreur", "horreur"), ("SF", "science-fiction")
    ]
    for name, slug in genres:
        add_item(name, "list_movies", f"{BASE_URL}/{slug}/")
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(url):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    add_item("[COLOR cyan]🏠 RETOUR MENU[/COLOR]", "main", "")
    add_item("[COLOR lightgreen]🔢 ALLER A LA PAGE...[/COLOR]", "jump_page", url)

    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        soup = BeautifulSoup(r, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        movie_data = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                movie_data.append({'title': title, 'url': link['href'], 'thumb': thumb})

        # Récupération ultra-rapide des résumés
        with ThreadPoolExecutor(max_workers=10) as executor:
            plots = list(executor.map(fetch_synopsis, [m['url'] for m in movie_data]))

        for i, m in enumerate(movie_data):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=plots[i])

        next_tag = soup.find('span', class_='pnext')
        if next_tag and next_tag.find('a'):
            add_item("[COLOR yellow]➡ PAGE SUIVANTE[/COLOR]", "list_movies", next_tag.find('a')['href'])
            
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

# --- Navigation Paginations ---

def jump_page(url_actuelle):
    n = xbmcgui.Dialog().numeric(0, 'Numéro de page :')
    if n and n != "0":
        # On nettoie l'URL (on retire /page/X si présent)
        base = re.sub(r'/page/\d+/?', '', url_actuelle).rstrip('/')
        new_url = f"{base}/" if str(n) == "1" else f"{base}/page/{n}/"
        
        # On force la redirection propre vers le router
        target = f"{sys.argv[0]}?action=list_movies&url={urllib.parse.quote_plus(new_url)}"
        xbmc.executebuiltin(f"Container.Update({target})")

# --- Lecture & Sources ---

def select_source(url, title, thumb, plot):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label=f"▶ LIEN SOURCE")
        li.setArt({'thumb': thumb})
        li.getVideoInfoTag().setPlot(plot)
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Rechercher un titre')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        q = urllib.parse.quote(kb.getText())
        list_movies(f"{BASE_URL}/index.php?do=search&subaction=search&story={q}")

# --- Point d'entrée ---

if __name__ == '__main__':
    p = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = p.get('action')
    
    if verifier_licence():
        if not action or action == 'main': main_menu()
        elif action == 'list_movies': list_movies(p.get('url'))
        elif action == 'jump_page': jump_page(p.get('url'))
        elif action == 'genres_menu': genres_menu()
        elif action == 'select_source': select_source(p.get('url'), p.get('title'), p.get('thumb'), p.get('plot'))
        elif action == 'play': play_video(p.get('url'))
        elif action == 'search': search()
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
