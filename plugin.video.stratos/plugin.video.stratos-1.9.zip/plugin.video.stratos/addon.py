def verifier_licence():
    # 1. Si déjà activé, on ne dit rien et on lance
    license_saved = ADDON.getSetting('stratflix_license_hash')
    if license_saved: 
        return True

    # 2. Clavier pour le premier code
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: 
        return False

    uuid = get_device_uuid()
    try:
        # Tentative de connexion
        payload = {'code': kb.upper().strip(), 'uuid': uuid}
        r = requests.post(URL_SERVEUR, data=payload, timeout=10)
        res = r.json()

        if res.get('status') == "success":
            # --- MESSAGE DE RÉUSSITE ---
            ADDON.setSetting('stratflix_license_hash', kb.upper())
            
            # On vérifie si les ressources de l'addon sont présentes (test d'installation)
            if os.path.exists(ADDON_PATH):
                xbmcgui.Dialog().ok("Installation Réussie", 
                    "Félicitations ! FlixPrimePlus est correctement configuré.\n"
                    "Votre appareil est activé et prêt à l'emploi.")
            else:
                xbmcgui.Dialog().warning("Attention", "Licence OK, mais certains fichiers manquent dans l'installation.")
            
            return True
        else:
            # --- MESSAGE D'ÉCHEC (Code invalide / déjà utilisé) ---
            xbmcgui.Dialog().ok("Échec de l'activation", 
                f"Erreur : {res.get('message')}\n\n"
                "Veuillez vérifier votre code ou contacter le support.")
            return False

    except Exception as e:
        # --- MESSAGE D'ÉCHEC (Serveur injoignable) ---
        xbmcgui.Dialog().ok("Erreur de Connexion", 
            "Impossible de joindre le serveur d'activation.\n"
            "Vérifiez votre connexion internet ou l'IP du serveur.")
        return False
