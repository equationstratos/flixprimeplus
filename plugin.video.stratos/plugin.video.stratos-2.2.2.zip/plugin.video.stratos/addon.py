# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    return os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)

# --- Sécurité ---
def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'): return True
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        if r.json().get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            return True
    except: pass
    return False

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("ACTION", "/film-en-streaming/action/", "action.png"),
        ("ANIMATION", "/film-en-streaming/animation/", "animation.png"),
        ("AVENTURE", "/film-en-streaming/aventure/", "adventure.png"),
        ("COMEDIE", "/film-en-streaming/comedie/", "comedy.png"),
        ("HORREUR", "/film-en-streaming/epouvante-horreur/", "horror.png"),
        ("DRAME", "/film-en-streaming/drame/", "drama.png"),
        ("SF", "/film-en-streaming/science-fiction/", "sci-fi.png"),
        ("THRILLER", "/film-en-streaming/thriller/", "thriller.png")
    ]
    for name, path, icon in genres:
        add_item(name, "list_movies", BASE_URL + path, thumb=get_art(icon))
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb: thumb = os.path.join(ADDON_PATH, 'icon.png')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot: li.getVideoInfoTag().setPlot(plot)
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping ---
def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc = soup.find('div', class_='screenshots-full')
        return desc.get_text(" ", strip=True).split("Synopsis:")[-1].strip() if desc else ""
    except: return ""

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    add_item("[COLOR cyan]RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("home.png"))

    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        if post_data:
            r = requests.post(url, headers=headers, data=post_data, timeout=10)
        else:
            r = requests.get(url, headers=headers, timeout=10)
        
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        # Nettoyage des pubs Flemmix
        if not post_data and len(items) > 42: items = items[30:-12]

        movie_list = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|en streaming|vf|vostfr', '', link.get_text()).strip(' -:')
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                movie_list.append({'title': title, 'url': link['href'], 'thumb': thumb})

        with ThreadPoolExecutor(max_workers=10) as executor:
            synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

        for i, m in enumerate(movie_list):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=synopses[i])

        # --- LOGIQUE DE PAGINATION (FIXEE) ---
        next_page_url = None
        nav = soup.find('div', class_='navigation')
        
        # 1. On cherche le lien "Suivant" dans le site
        if nav:
            next_link = nav.find('a', string=re.compile(r'Suivant|Next|>', re.IGNORECASE))
            if next_link: next_page_url = next_link['href']
        
        # 2. Si pas trouvé (souvent en recherche), on le calcule
        if not next_page_url and not post_data:
            match = re.search(r'/page/(\d+)', url)
            curr = int(match.group(1)) if match else 1
            if match:
                next_page_url = url.replace(f'/page/{curr}', f'/page/{curr + 1}')
            else:
                next_page_url = url.rstrip('/') + f'/page/2/'

        # Affichage du bouton Suivant
        if next_page_url:
            if not next_page_url.startswith('http'): next_page_url = BASE_URL + next_page_url
            add_item("[COLOR green][B]PAGE SUIVANTE[/B][/COLOR]", "list_movies", next_page_url, thumb=get_art("next.png"))

        # TON BOUTON ALLER A LA PAGE
        if not post_data:
            add_item("[COLOR yellow]ALLER A LA PAGE...[/COLOR]", "jump_page", url, thumb=get_art("keyboard.png"))

    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

# --- TA FONCTION JUMP ---
def jump_page(url):
    dialog = xbmcgui.Dialog()
    page_num = dialog.numeric(0, 'Numero de page :')
    if page_num:
        base = re.sub(r'/page/\d+/?', '/', url).rstrip('/')
        new_url = f"{base}/page/{page_num}/"
        list_movies(new_url)

# --- Sources & Lecture ---
def select_source(url):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label="▶ SOURCE VIDEO")
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        # Recherche POST pour Flemmix
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", post_data=data)

# --- Router ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    
    if verifier_licence():
        if not action or action == 'main': main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'jump_page': jump_page(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
