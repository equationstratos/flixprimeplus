# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menu', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Système de Sécurité avec Messages ---

def get_device_uuid():
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        return hashlib.sha256(raw_id.encode()).hexdigest()
    except: return "uuid_static_kodi"

def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'):
        return True

    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False

    uuid = get_device_uuid()
    try:
        payload = {'code': kb.upper().strip(), 'uuid': uuid}
        r = requests.post(URL_SERVEUR, data=payload, timeout=10)
        res = r.json()

        if res.get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            xbmcgui.Dialog().ok("Installation Réussie", "Félicitations !\nFlixPrimePlus est activé et prêt à l'emploi.")
            return True
        else:
            xbmcgui.Dialog().ok("Échec d'activation", f"Erreur : {res.get('message')}")
            return False
    except:
        xbmcgui.Dialog().ok("Erreur Connexion", "Le serveur d'activation est injoignable.")
        return False

# --- Menus ---

def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("Action", "action"), ("Animation", "animation"), ("Aventure", "aventure"),
        ("Comédie", "comedie"), ("Drame", "drame"), ("Horreur", "horreur"),
        ("Science-Fiction", "science-fiction"), ("Thriller", "thriller")
    ]
    for name, slug in genres:
        add_item(f"[COLOR white]{name}[/COLOR]", "list_movies", f"{BASE_URL}/{slug}/")
    xbmcplugin.endOfDirectory(HANDLE)

# --- Navigation & Scraping ---

def add_item(name, action, url, thumb="", plot="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb})
    if plot: li.getVideoInfoTag().setPlot(plot)
    params = {'action': action, 'url': url}
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def list_movies(url):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    # Boutons de contrôle en haut
    add_item("[COLOR cyan]🏠 RETOUR AU MENU PRINCIPAL[/COLOR]", "main", "", thumb=get_art("home.png"))
    add_item("[COLOR lightgreen]🔢 ALLER A LA PAGE...[/COLOR]", "go_to_page", url, thumb=get_art("go_page.png"))

    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        soup = BeautifulSoup(r, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                
                li = xbmcgui.ListItem(label=title)
                li.setArt({'thumb': thumb, 'poster': thumb})
                q = urllib.parse.urlencode({'action': 'select_source', 'url': link['href'], 'title': title, 'thumb': thumb})
                xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)

        next_tag = soup.find('span', class_='pnext')
        if next_tag and next_tag.find('a'):
            add_item("[COLOR yellow]➡ PAGE SUIVANTE[/COLOR]", "list_movies", next_tag.find('a')['href'], thumb=get_art("next.png"))
            
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def go_to_page(url_actuelle):
    # Clavier numérique
    n_page = xbmcgui.Dialog().numeric(0, 'Numéro de page')
    
    if n_page:
        # Nettoyage URL
        base = re.sub(r'page/\d+/?', '', url_actuelle).rstrip('/')
        new_url = f"{base}/page/{n_page}/" if str(n_page) != "1" else f"{base}/"
        
        # Commande de mise à jour forcée
        path = f"{sys.argv[0]}?action=list_movies&url={urllib.parse.quote_plus(new_url)}"
        xbmc.executebuiltin(f"Container.Update({path})")

# --- Sources & Lecture ---

def select_source(url, title, thumb):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label=f"▶ LIEN SOURCE")
        li.setArt({'thumb': thumb})
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        search_url = f"{BASE_URL}/index.php?do=search&subaction=search&story={urllib.parse.quote(kb.getText())}"
        list_movies(search_url)

# --- Router ---

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    
    if verifier_licence():
        if not action or action == 'main': main_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'go_to_page': go_to_page(params.get('url'))
        elif action == 'genres_menu': genres_menu()
        elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
