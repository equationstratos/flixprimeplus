# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
import time
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration de l'Addon ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

# IP de ton serveur local (Vérifie qu'elle est toujours 107)
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def log(msg):
    xbmc.log(f"FLIXPRIME_DEBUG: {msg}", xbmc.LOGINFO)

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menu', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Système de Sécurité UUID + PHP/MySQL ---

def get_device_uuid():
    """Génère un identifiant unique pour verrouiller la licence."""
    try:
        # On utilise le nom de l'appareil pour créer une empreinte unique
        friendly_name = xbmc.getInfoLabel('System.FriendlyName')
        kernel = xbmc.getInfoLabel('System.KernelVersion')
        raw_id = f"{friendly_name}|{kernel}"
        return hashlib.sha256(raw_id.encode()).hexdigest()
    except:
        return "uuid_static_device_001"

def verifier_licence():
    # 1. Vérification si déjà activé localement (évite de requêter le serveur à chaque clic)
    license_saved = ADDON.getSetting('stratflix_license_hash')
    if license_saved:
        return True

    # 2. Demande du code via le clavier Kodi
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb:
        return False

    uuid = get_device_uuid()
    
    try:
        xbmcgui.Dialog().notification("Sécurité", "Vérification sur le serveur...", xbmcgui.NOTIFICATION_INFO, 3000)
        
        # Préparation des données et des Headers
        payload = {'code': kb.upper().strip(), 'uuid': uuid}
        headers = {
            'User-Agent': USER_AGENT,
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        # Envoi de la requête POST au serveur PHP
        r = requests.post(URL_SERVEUR, data=payload, headers=headers, timeout=12)
        
        # Debug : Si le serveur répond autre chose que 200 (OK)
        if r.status_code != 200:
            xbmcgui.Dialog().ok("Erreur Serveur", f"Code HTTP : {r.status_code}\nLe serveur est injoignable ou mal configuré.")
            return False

        res = r.json()

        if res.get('status') == "success":
            # Sauvegarde locale pour les prochaines utilisations
            ADDON.setSetting('stratflix_license_hash', kb.upper())
            xbmcgui.Dialog().ok("Succès", "Votre appareil est maintenant activé !")
            return True
        else:
            # Message renvoyé par le PHP (ex: "Code déjà utilisé")
            xbmcgui.Dialog().ok("Activation Refusée", res.get('message', 'Erreur inconnue'))
            return False

    except requests.exceptions.Timeout:
        xbmcgui.Dialog().ok("Erreur", "Délai d'attente dépassé (Le serveur ne répond pas).")
        return False
    except Exception as e:
        xbmcgui.Dialog().ok("Erreur Critique", f"Impossible de joindre l'API.\nVerifiez l'IP : {URL_SERVEUR}\nErreur : {str(e)}")
        log(f"Erreur Connexion API: {str(e)}")
        return False

# --- Gestion des Menus ---

def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("ACTION", "/film-en-streaming/action/", "action.png"),
        ("ANIMATION", "/film-en-streaming/animation/", "animation.png"),
        ("AVENTURE", "/film-en-streaming/aventure/", "adventure.png"),
        ("COMEDIE", "/film-en-streaming/comedie/", "comedy.png"),
        ("HORREUR", "/film-en-streaming/epouvante-horreur/", "horror.png"),
        ("SCIENCE FICTION", "/film-en-streaming/science-fiction/", "sci-fi.png"),
        ("THRILLER", "/film-en-streaming/thriller/", "thriller.png")
    ]
    for name, path, icon in genres:
        add_item(name, "list_movies", BASE_URL + path, thumb=get_art(icon))
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", plot="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
    q = urllib.parse.urlencode({'action': action, 'url': url, 'plot': plot, 'thumb': thumb})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Logique de Scraping ---

def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc = soup.find('div', class_='screenshots-full')
        return desc.get_text(" ", strip=True).split("Synopsis:")[-1] if desc and "Synopsis:" in desc.get_text() else "Pas de résumé disponible."
    except: return "Erreur lors de la récupération du résumé."

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    try:
        r_text = requests.post(url, headers={'User-Agent': USER_AGENT}, data=post_data, timeout=10).text if post_data else requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        soup = BeautifulSoup(r_text, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        movie_list = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                movie_list.append({'title': title, 'url': link['href'], 'thumb': thumb})

        with ThreadPoolExecutor(max_workers=10) as executor:
            synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

        for i, m in enumerate(movie_list):
            li = xbmcgui.ListItem(label=m['title'])
            li.setArt({'thumb': m['thumb'], 'poster': m['thumb'], 'fanart': m['thumb']})
            info = li.getVideoInfoTag()
            info.setPlot(synopses[i])
            info.setMediaType('movie')
            
            params = {'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb'], 'plot': synopses[i]}
            q = urllib.parse.urlencode(params)
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)
            
    except:
        xbmcgui.Dialog().notification("Erreur", "Impossible de charger la liste.", xbmcgui.NOTIFICATION_ERROR)
        
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url, title, thumb, plot):
    xbmcplugin.setContent(HANDLE, 'movies')
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        srv = "SOURCE"
        if "voe" in v_url: srv = "VOE"
        elif "vidmoly" in v_url: srv = "VIDMOLY"
        elif "uqload" in v_url: srv = "UQLOAD"
        
        li = xbmcgui.ListItem(label=f"▶ REGARDER VIA {srv}")
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb, 'icon': thumb})
        info = li.getVideoInfoTag()
        info.setPlot(plot)
        info.setTitle(title)
        info.setMediaType('movie') 
        
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: 
        xbmcgui.Dialog().notification("Lien", "Impossible de résoudre le lien.", xbmcgui.NOTIFICATION_ERROR)

def search():
    kb = xbmc.Keyboard('', 'Recherche de films/séries')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- ROUTER PRINCIPAL ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    # On vérifie la licence avant tout
    if verifier_licence():
        if not action: main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'select_source': 
            select_source(params.get('url'), params.get('title'), params.get('thumb'), params.get('plot'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else:
        # En cas d'échec de licence, on ferme le dossier Kodi
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
