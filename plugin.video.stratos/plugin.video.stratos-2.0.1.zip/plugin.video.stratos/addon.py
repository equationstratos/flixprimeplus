# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def log(msg):
    xbmc.log(f"FLIXPRIME_DEBUG: {msg}", xbmc.LOGINFO)

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menu', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Sécurité & Installation ---

def get_device_uuid():
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        return hashlib.sha256(raw_id.encode()).hexdigest()
    except: return "uuid_static_kodi"

def verifier_licence():
    license_saved = ADDON.getSetting('stratflix_license_hash')
    if license_saved:
        return True

    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False

    uuid = get_device_uuid()
    try:
        payload = {'code': kb.upper().strip(), 'uuid': uuid}
        r = requests.post(URL_SERVEUR, data=payload, timeout=10)
        res = r.json()

        if res.get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            xbmcgui.Dialog().ok("Installation Terminée", "L'application a été installée avec succès !")
            return True
        else:
            xbmcgui.Dialog().ok("Échec", f"Erreur : {res.get('message')}")
            return False
    except:
        xbmcgui.Dialog().ok("Erreur", "Serveur injoignable.")
        return False

# --- Menu Principal ---

def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

# --- Navigation & Scraping ---

def add_item(name, action, url, thumb="", plot="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot: li.getVideoInfoTag().setPlot(plot)
    # On s'assure que l'URL est bien encodée pour éviter les erreurs de caractères
    params = {'action': action, 'url': url}
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    # Boutons de navigation
    add_item("[COLOR cyan]🏠 RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("home.png"))
    # Correction ici : on passe bien l'URL actuelle pour savoir où on est
    add_item("[COLOR lightgreen]🔢 ALLER A LA PAGE...[/COLOR]", "go_to_page", url, thumb=get_art("go_page.png"))

    try:
        r_text = requests.post(url, headers={'User-Agent': USER_AGENT}, data=post_data).text if post_data else requests.get(url, headers={'User-Agent': USER_AGENT}).text
        soup = BeautifulSoup(r_text, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        movie_list = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                movie_list.append({'title': title, 'url': link['href'], 'thumb': thumb})

        with ThreadPoolExecutor(max_workers=10) as executor:
            synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

        for i, m in enumerate(movie_list):
            li = xbmcgui.ListItem(label=m['title'])
            li.setArt({'thumb': m['thumb'], 'poster': m['thumb']})
            li.getVideoInfoTag().setPlot(synopses[i])
            li.getVideoInfoTag().setMediaType('movie')
            params = {'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb'], 'plot': synopses[i]}
            q = urllib.parse.urlencode(params)
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)

        next_tag = soup.find('span', class_='pnext')
        if next_tag and next_tag.find('a'):
            add_item("[COLOR yellow]➡ PAGE SUIVANTE[/COLOR]", "list_movies", next_tag.find('a')['href'], thumb=get_art("next.png"))
    except Exception as e:
        log(f"Erreur list_movies: {str(e)}")
    
    xbmcplugin.endOfDirectory(HANDLE)

def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc = soup.find('div', class_='screenshots-full')
        return desc.get_text(" ", strip=True).split("Synopsis:")[-1] if desc and "Synopsis:" in desc.get_text() else "Pas de résumé."
    except: return "Indisponible."

def go_to_page(url_actuelle):
    # Cette fois le clavier s'ouvrira car l'action est bien routée
    kb = xbmcgui.Dialog().input("Numéro de page", type=xbmcgui.INPUT_NUMBER)
    if kb and kb.isdigit():
        # On nettoie l'URL pour la pagination
        base = re.sub(r'page/\d+/?', '', url_actuelle).rstrip('/')
        if kb == "1":
            new_url = f"{base}/"
        else:
            new_url = f"{base}/page/{kb}/"
        
        # On relance la liste avec la nouvelle URL
        xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=list_movies&url={urllib.parse.quote_plus(new_url)})")

def select_source(url, title, thumb, plot):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label=f"▶ LIEN SOURCE")
        li.setArt({'thumb': thumb})
        li.getVideoInfoTag().setPlot(plot)
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- Router ---

if __name__ == '__main__':
    # Lecture des paramètres envoyés par Kodi
    raw_params = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    params = dict(urllib.parse.parse_qsl(raw_params))
    action = params.get('action')
    
    if verifier_licence():
        if not action or action == 'main':
            main_menu()
        elif action == 'list_movies':
            list_movies(params.get('url'))
        elif action == 'go_to_page':
            # On récupère l'URL passée en paramètre
            go_to_page(params.get('url'))
        elif action == 'select_source':
            select_source(params.get('url'), params.get('title'), params.get('thumb'), params.get('plot'))
        elif action == 'play':
            play_video(params.get('url'))
        elif action == 'search':
            search()
        elif action == 'genres_menu':
            # Ajoute ta fonction genre ici si besoin
            pass
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
