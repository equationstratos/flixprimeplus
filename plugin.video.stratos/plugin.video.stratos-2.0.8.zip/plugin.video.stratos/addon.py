# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Sécurité ---

def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'):
        return True
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        res = r.json()
        if res.get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            xbmcgui.Dialog().ok("Succès", "Activé !")
            return True
        else:
            xbmcgui.Dialog().ok("Erreur", res.get('message'))
            return False
    except: return False

# --- Scraping ---

def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc = soup.find('div', class_='screenshots-full')
        if desc:
            text = desc.get_text(" ", strip=True)
            return text.split("Synopsis:")[-1] if "Synopsis:" in text else text
    except: pass
    return "Aucun résumé."

def add_item(name, action, url, thumb="", plot="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot: li.getVideoInfoTag().setPlot(plot)
    params = {'action': action, 'url': url, 'plot': plot, 'thumb': thumb}
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Menus ---

def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "")
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/")
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/")
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [("Action", "action"), ("Animation", "animation"), ("Aventure", "aventure"), ("Horreur", "horreur")]
    for name, slug in genres:
        add_item(name, "list_movies", f"{BASE_URL}/{slug}/")
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(url):
    xbmcplugin.setContent(HANDLE, 'movies')
    add_item("[COLOR cyan]🏠 MENU[/COLOR]", "main", "")
    # Bouton Aller à la page
    add_item("[COLOR lightgreen]🔢 ALLER A LA PAGE...[/COLOR]", "go_to_page", url)

    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        soup = BeautifulSoup(r, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        results = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                results.append({'title': title, 'url': link['href'], 'thumb': thumb})

        with ThreadPoolExecutor(max_workers=10) as executor:
            plots = list(executor.map(fetch_synopsis, [m['url'] for m in results]))

        for i, m in enumerate(results):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=plots[i])

        next_tag = soup.find('span', class_='pnext')
        if next_tag and next_tag.find('a'):
            add_item("[COLOR yellow]➡ SUIVANT[/COLOR]", "list_movies", next_tag.find('a')['href'])
            
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

# --- CORRECTION FINALE PAGINATION ---
def go_to_page(url_actuelle):
    n_page = xbmcgui.Dialog().numeric(0, 'Numéro de page')
    if n_page:
        # On nettoie l'URL de TOUT résidu de page (même mal formé)
        base = re.sub(r'/page/\d+/?', '', url_actuelle).rstrip('/')
        
        if str(n_page) == "1":
            new_url = f"{base}/"
        else:
            new_url = f"{base}/page/{n_page}/"
        
        # On force Kodi à mettre à jour le container actuel
        path = f"{sys.argv[0]}?action=list_movies&url={urllib.parse.quote_plus(new_url)}"
        xbmc.executebuiltin(f"Container.Update({path})")

# --- Sources & Lecture ---

def select_source(url, title, thumb, plot):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        li = xbmcgui.ListItem(label=f"▶ SOURCE VIDEO")
        li.setArt({'thumb': thumb})
        li.getVideoInfoTag().setPlot(plot)
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        search_url = f"{BASE_URL}/index.php?do=search&subaction=search&story={urllib.parse.quote(kb.getText())}"
        list_movies(search_url)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    
    if verifier_licence():
        if not action or action == 'main': main_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'go_to_page': go_to_page(params.get('url'))
        elif action == 'genres_menu': genres_menu()
        elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'), params.get('plot'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else: xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
