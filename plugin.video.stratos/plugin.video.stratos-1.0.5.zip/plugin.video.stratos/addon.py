# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

# --- Configuration Images LOCALES ---
def get_art(filename):
    """Va chercher l'image dans le dossier resources/icones-menu de l'addon"""
    return os.path.join(ADDON_PATH, 'resources', 'icones-menu', filename)

# --- Menus ---

def main_menu():
    # Ici Kodi cherche directement dans ton dossier local
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"), fanart=get_art("fanart_movies.jpg"))
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"), fanart=get_art("fanart_series.jpg"))
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"), fanart=get_art("fanart_genres.jpg"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    add_item("[COLOR cyan]RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("home.png"))
    
    genres = [
        ("ACTION", "/film-en-streaming/action/", "action.png"),
        ("ANIMATION", "/film-en-streaming/animation/", "animation.png"),
        ("ARTS MARTIAUX", "/film-en-streaming/arts-martiaux/", "karate.png"),
        ("AVENTURE", "/film-en-streaming/aventure/", "adventure.png"),
        ("BIOPIC", "/film-en-streaming/biopic/", "biopic.png"),
        ("COMEDIE", "/film-en-streaming/comedie/", "comedy.png"),
        ("HORREUR", "/film-en-streaming/epouvante-horreur/", "horror.png"),
        ("DRAME", "/film-en-streaming/drame/", "drama.png"),
        ("FANTASTIQUE", "/film-en-streaming/fantastique/", "fantasy.png"),
        ("POLICIER", "/film-en-streaming/policier/", "police.png"),
        ("SCIENCE FICTION", "/film-en-streaming/science-fiction/", "sci-fi.png"),
        ("THRILLER", "/film-en-streaming/thriller/", "thriller.png")
    ]
    
    for name, path, icon in genres:
        add_item(f"[COLOR white]{name}[/COLOR]", "list_movies", BASE_URL + path, thumb=get_art(icon), fanart=get_art("fanart_genres.jpg"))
        
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", fanart="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    
    # Images par défaut si les fichiers spécifiques sont absents
    if not fanart or not os.path.exists(fanart):
        fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    if not thumb or not os.path.exists(thumb):
        thumb = os.path.join(ADDON_PATH, 'icon.png')

    li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': fanart})
    
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
        
    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping ---

def get_html(url, post_data=None):
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def fetch_synopsis(movie_url):
    html = get_html(movie_url)
    if not html: return ""
    soup = BeautifulSoup(html, 'html.parser')
    desc_block = soup.find('div', class_='screenshots-full')
    if desc_block:
        text = desc_block.get_text(" ", strip=True)
        if "Synopsis:" in text: return text.split("Synopsis:")[-1].strip()
    return "Cliquez pour voir les sources."

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    add_item("[COLOR cyan]RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("home.png"))

    html = get_html(url, post_data)
    if not html: 
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div', class_='mov')
    
    if not post_data and len(items) > 42:
        items = items[30:-12]

    movie_list = []
    for item in items:
        link_tag = item.find('a', class_='mov-t')
        if link_tag:
            title = re.sub(r'(?i)flemmix|en streaming|vf|vostfr', '', link_tag.get_text(strip=True)).strip(' -:').strip()
            href = link_tag['href']
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
            movie_list.append({'title': title, 'url': href, 'thumb': thumb})

    with ThreadPoolExecutor(max_workers=10) as executor:
        synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

    for i, m in enumerate(movie_list):
        li = xbmcgui.ListItem(label=m['title'])
        li.setArt({'thumb': m['thumb'], 'poster': m['thumb'], 'fanart': m['thumb']})
        info = li.getVideoInfoTag()
        info.setPlot(synopses[i])
        info.setMediaType('movie')
        q = urllib.parse.urlencode({'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb']})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, True)

    # --- PAGINATION ---
    next_page_url = None
    nav = soup.find('div', class_='navigation')
    if nav:
        next_link = nav.find('a', string=re.compile(r'Suivant|Next|>>|>', re.IGNORECASE))
        if next_link and next_link.has_attr('href'):
            next_page_url = next_link['href']
    
    if not next_page_url and not post_data:
        match = re.search(r'/page/(\d+)', url)
        curr = int(match.group(1)) if match else 1
        next_page_url = url.replace(f'/page/{curr}', f'/page/{curr + 1}') if match else url.rstrip('/') + '/page/2/'

    if next_page_url:
        if not next_page_url.startswith('http'): next_page_url = BASE_URL + next_page_url
        add_item("[COLOR green][B]PAGE SUIVANTE[/B][/COLOR]", "list_movies", next_page_url, thumb=get_art("next.png"))
        
        if not post_data:
            q_jump = urllib.parse.urlencode({'action': 'jump_page', 'url': url})
            li_jump = xbmcgui.ListItem(label="[COLOR yellow]ALLER A LA PAGE...[/COLOR]")
            li_jump.setArt({'thumb': get_art("keyboard.png"), 'icon': get_art("keyboard.png")})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q_jump}", li_jump, True)

    xbmcplugin.endOfDirectory(HANDLE)

def jump_page(url):
    dialog = xbmcgui.Dialog()
    page_num = dialog.numeric(0, 'Numero de page :')
    if page_num:
        base = re.sub(r'/page/\d+/?', '/', url).rstrip('/')
        new_url = f"{base}/page/{page_num}/"
        list_movies(new_url)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    plot = fetch_synopsis(url)
    servers = {'voe.sx': 'VOE', 'uqload': 'UQLOAD', 'vidmoly': 'VIDMOLY', 'dsvplay': 'DDSTREAM', 'luluvdo': 'LULUTV', 'waaw': 'NETU', 'minochinos': 'FILELIONS'}
    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        srv_name = "SOURCE"
        for key, name in servers.items():
            if key in v_url.lower(): srv_name = name; break
        li = xbmcgui.ListItem(label=f"LIEN {srv_name}")
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')
        info = li.getVideoInfoTag()
        info.setPlot(plot)
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Recherche')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", data)

# --- Router ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
action = params.get('action')
if not action or action == 'main': main_menu()
elif action == 'genres_menu': genres_menu()
elif action == 'list_movies': list_movies(params.get('url'))
elif action == 'jump_page': jump_page(params.get('url'))
elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
elif action == 'play': play_video(params.get('url'))
elif action == 'search': search()
