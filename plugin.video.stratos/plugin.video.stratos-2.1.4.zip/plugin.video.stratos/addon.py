# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Sécurité ---
def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'):
        return True
    
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb:
        return False
    
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        if r.json().get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            return True
    except:
        pass
    return False

# --- Scraping ---
def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc = soup.find('div', class_='screenshots-full')
        if desc and "Synopsis:" in desc.get_text():
            return desc.get_text(" ", strip=True).split("Synopsis:")[-1].strip()
        return "Pas de résumé."
    except:
        return "Indisponible."

def add_item(name, action, url, thumb="", plot="", is_folder=True):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    params = {'action': action, 'url': url}
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]RECHERCHE[/COLOR]", "search", "")
    add_item("[COLOR white]FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/")
    add_item("[COLOR lightblue]SERIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/")
    add_item("[COLOR orange]GENRES[/COLOR]", "genres_menu", "")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [("Action", "action"), ("Animation", "animation"), ("Aventure", "aventure"), ("Horreur", "horreur")]
    for name, slug in genres:
        add_item(name, "list_movies", f"{BASE_URL}/{slug}/")
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(url):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    add_item("[COLOR cyan]🏠 MENU[/COLOR]", "main", "")
    add_item("[COLOR lightgreen]🔢 ALLER A LA PAGE...[/COLOR]", "jump_page", url)
    
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        soup = BeautifulSoup(r, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        movie_data = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if link:
                title = re.sub(r'(?i)flemmix|streaming|vf|vostfr', '', link.get_text()).strip()
                img = item.find('img')
                thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else (img['src'] if img else "")
                movie_data.append({'title': title, 'url': link['href'], 'thumb': thumb})
        
        if movie_data:
            with ThreadPoolExecutor(max_workers=10) as executor:
                plots = list(executor.map(fetch_synopsis, [m['url'] for m in movie_data]))
            
            for i, m in enumerate(movie_data):
                add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=plots[i])
        
        # Pagination
        next_tag = soup.find('span', class_='pnext')
        if next_tag and next_tag.find('a'):
            add_item("[COLOR yellow]➡ SUIVANT[/COLOR]", "list_movies", next_tag.find('a')['href'])
            
    except Exception as e:
        xbmcgui.Dialog().notification("Erreur", str(e)[:100], xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- FONCTION JUMP PAGE corrigée ---
def jump_page(current_url):
    # Récupérer la page actuelle pour l'afficher en indication
    current_page = "1"
    m = re.search(r'/page/(\d+)/?$', current_url)
    if m:
        current_page = m.group(1)
    
    page_num_str = xbmcgui.Dialog().numeric(0, f'Aller à la page (actuel : {current_page})', defaultt=current_page)
    
    if not page_num_str:
        return  # Annulation
    
    try:
        page_num = int(page_num_str)
        if page_num < 1:
            page_num = 1
    except:
        xbmcgui.Dialog().notification("Erreur", "Numéro invalide", xbmcgui.NOTIFICATION_ERROR)
        return
    
    # Construction de la nouvelle URL
    base = re.sub(r'/page/\d+/?$', '', current_url).rstrip('/')
    
    if page_num == 1:
        new_url = base + '/'
    else:
        new_url = f"{base}/page/{page_num}/"
    
    # Préparation des paramètres
    params = {
        'action': 'list_movies',
        'url': new_url
    }
    
    encoded_params = urllib.parse.urlencode(params)
    plugin_call = f"{sys.argv[0]}?{encoded_params}"
    
    # Méthode la plus fiable pour forcer le changement de page
    xbmc.executebuiltin(f'RunPlugin({plugin_call})')
    xbmc.sleep(400)           # petit délai pour laisser le temps au RunPlugin de démarrer
    xbmc.executebuiltin('Container.Refresh')

# --- Sources & Lecture ---
def select_source(url, title=None, thumb=None, plot=None):
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=12).text
        matches = re.findall(r"loadVideo\('(.+?)'\)", r)
        
        added = False
        for v_url in set(matches):
            if v_url.startswith('//'):
                v_url = "https:" + v_url
            li = xbmcgui.ListItem(label="▶ Source")
            if thumb:
                li.setArt({'thumb': thumb})
            li.setProperty('IsPlayable', 'true')
            q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
            added = True
        
        if not added:
            xbmcgui.Dialog().notification("Aucune source", "Aucune vidéo trouvée", xbmcgui.NOTIFICATION_INFO)
            
    except Exception as ex:
        xbmcgui.Dialog().notification("Erreur source", str(ex)[:80], xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        resolved = resolveurl.resolve(url)
        if resolved:
            xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=resolved))
        else:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    except:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- Router ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    
    if verifier_licence():
        if not action or action == 'main':
            main_menu()
        elif action == 'list_movies':
            list_movies(params.get('url', f"{BASE_URL}/film-en-streaming/"))
        elif action == 'jump_page':
            jump_page(params.get('url', ''))
        elif action == 'genres_menu':
            genres_menu()
        elif action == 'select_source':
            select_source(
                params.get('url', ''),
                params.get('title'),
                params.get('thumb'),
                params.get('plot')
            )
        elif action == 'play':
            play_video(params.get('url', ''))
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
